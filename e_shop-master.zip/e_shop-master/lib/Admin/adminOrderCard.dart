import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:e_shop/Admin/adminOrderDetails.dart';
import 'package:e_shop/Models/item.dart';
import 'package:flutter/material.dart';

import '../Store/storehome.dart';


int counter=0;
class AdminOrderCard extends StatelessWidget
{

  @override
  Widget build(BuildContext context)
  {
    return  InkWell();
  }
}



Widget sourceInfo(ItemModel model, BuildContext context,
    {Color background})
{

  return  Container();
}
