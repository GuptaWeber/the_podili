
import 'package:flutter/foundation.dart';

class AddressChanger extends ChangeNotifier{
}