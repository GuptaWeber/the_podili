import 'package:flutter/cupertino.dart';

class TotalAmount extends ChangeNotifier{
}