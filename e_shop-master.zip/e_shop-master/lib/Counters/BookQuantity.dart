import 'package:flutter/foundation.dart';

class BookQuantity with ChangeNotifier {
}
